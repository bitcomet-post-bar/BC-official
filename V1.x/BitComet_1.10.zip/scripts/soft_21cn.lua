﻿function url_process(linkurl, fileurl, referurl, str)
    local pattern_name = "如果不能自动下载，请点击下面的链接进行手动下载.-<[Ff][Oo][Nn][Tt].->%s*(.-)%s*下载</[Ff][Oo][Nn][Tt]>"
    local pattern_ext  = ".*(%..-)$"
    local start, _, tmp

    local base_name, ext

    start, _, tmp = string.find(str, pattern_name)
    --print(start, tmp)
    if start == nil then return ""  else base_name = tmp end

    start, _, tmp = string.find(linkurl, pattern_ext)
    --print(start, tmp)
    if start == nil then return "" else ext = tmp end 

    return base_name .. ext
end

function url_query(str)
    local start

	start = string.find(str, "http://dl%.it%.21cn%.com/downit%.php")
	if start ~= nil then return true end

	return false
end

f = {}
f.process = url_process
f.accept = url_query
intelligent_name_table["soft_21cn.lua"] = f

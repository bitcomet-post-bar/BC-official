﻿function url_process(linkurl, fileurl, referurl, str)
    local pattern_name = "歌曲名:</STRONG><A.->%s*(.-)%s*</A>"
	local pattern_artist = "歌手名:</STRONG><A.->%s*(.-)%s*</A>"
    local pattern_ext  = ".*(%..-)$"
    local start, _, tmp

    local base_name, artist, ext

    start, _, tmp = string.find(str, pattern_name)
    --print(start, tmp)
    if start == nil then return ""  else base_name = tmp end

    start, _, tmp = string.find(str, pattern_artist)
    --print(start, tmp)
	if tmp ~= nil then artist = tmp end

    start, _, tmp = string.find(linkurl, pattern_ext)
    --print(start, tmp)
    if start == nil then return "" else ext = tmp end 

	if artist ~= nil then base_name = artist .. " - " .. base_name end 

    return base_name .. ext
end

function url_query(str)
    local start
    local pattern_url = "music%.sogua%.com"

    start = string.find(str, pattern_url)
    if start == nil then
        return false
    end

    return true
end

f = {}
f.process = url_process
f.accept = url_query
intelligent_name_table["mp3_sogua.lua"] = f

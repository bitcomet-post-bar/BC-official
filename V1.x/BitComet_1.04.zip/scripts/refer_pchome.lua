local function f(url)
	local url_pattern = "http://download%.pchome%.net/php/tdownload2%.php"
	local cookie = "ddddPcdsxPchome=1; PChomeTrackId=6873605; PChomeTrackFirstTime=1178607019609; PChomeTrackReturnTime=1178607019609" 

	if nil == string.find(url, url_pattern) then 
		return nil, nil
	else
		return nil, cookie
	end
end

referer_table["refer_pchome.lua"] = f

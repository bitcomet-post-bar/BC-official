cookie_table["newhua.com"] = "Flag=UUIISPoweredByUUSoft"
cookie_table["onlinedown.net"] = "Flag=UUIISPoweredByUUSoft"
cookie_table["pchome.net"] = "ddddPcdsxPchome=1; PChomeTrackId=6873605; PChomeTrackFirstTime=1178607019609; PChomeTrackReturnTime=1178607019609"

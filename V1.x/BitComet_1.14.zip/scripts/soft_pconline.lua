﻿function url_process(linkurl, fileurl, referurl, str)
    local pattern_name = "<[Tt][Ii][Tt][Ll][Ee]>%s*(.-)%s*下载_.-_太平洋下载中心</[Tt][Ii][Tt][Ll][Ee]>"
    local pattern_ext  = ".*(%..*)%s*$"
    local start, _, tmp

    local base_name, ext

    start, _, tmp = string.find(str, pattern_name)
    --print(start, tmp)
    if start == nil then return ""  else base_name = tmp end

	if fileurl ~= nil then
	  linkurl = fileurl
	end
    start, _, tmp = string.find(linkurl, pattern_ext)
    if start == nil then return "" else ext = tmp end 

    return base_name .. ext
end

function url_query(str)
    local start
    local pattern_url = "http://dl%.pconline%.com%.cn/"

    start = string.find(str, pattern_url)
    if start == nil then return false end

    return true
end

f = {}
f.process = url_process
f.accept = url_query
intelligent_name_table["soft_pconline.lua"] = f

local function f(url)
	local url_pattern = "%s*http://downloads.sourceforge.net/"
	local cookie = nil
	if nil == string.find(url, url_pattern) then 
		return nil, cookie
	else
		return "http://sourceforge.net/project/downloading.php", cookie
	end
end

referer_table["refer_sourceforge.lua"] = f

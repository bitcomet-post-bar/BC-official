﻿function url_process(linkurl, fileurl, referurl, str)
    local pattern_name = "<DIV id=song style=\"DISPLAY: none\">(.-)%s*<"
	local pattern_artist = "<DIV id=singer style=\"DISPLAY: none\">(.-)%s*<"
    local pattern_ext  = ".*(%..-)$"
    local start, _, tmp

    local base_name, artist, ext

    start, _, tmp = string.find(str, pattern_name)
    --print(start, tmp)
    if start == nil then return ""  else base_name = tmp end

    start, _, tmp = string.find(str, pattern_artist)
    --print(start, tmp)
	if tmp ~= nil then artist = tmp end

    start, _, tmp = string.find(linkurl, pattern_ext)
    --print(start, tmp)
    if start == nil then return "" else ext = tmp end 

	if artist ~= nil then base_name = artist .. " - " .. base_name end 

    return base_name .. ext
end

function url_query(str)
    local start
	local url_table = {}
	local i

	url_table[0] = "202%.108%.23%.172"
	url_table[1] = "220%.181%.38%.82"
	url_table[2] = "box%.zhangmen%.baidu%.com"
	
	--print("baidu: ")
	--print(str)

	for i = 0,2 do
		start = string.find(str, url_table[i])
		if start ~= nil then return true end
	end

    return false
end

f = {}
f.process = url_process
f.accept = url_query
intelligent_name_table["mp3_baidu.lua"] = f

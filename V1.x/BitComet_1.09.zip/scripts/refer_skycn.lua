local function f(url)
	local url_pattern = "%s*http://.-%.skycn%.com/"
	local rand = math.random(1, 5000);
	local cookie = nil
	if nil == string.find(url, url_pattern) then 
		return nil, cookie
	else
		return "http://www.skycn.com/soft/".. rand .. ".html", cookie
	end
end

referer_table["refer_skycn.lua"] = f

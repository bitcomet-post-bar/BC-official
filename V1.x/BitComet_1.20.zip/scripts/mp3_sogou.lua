﻿function url_process(linkurl, fileurl, referurl, str)
    local pattern_ext     = ".*(%..-)$"
    local start, _, tmp

    local base_name, ext, artist

    start = string.find(referurl, "ting%.mbox%.sogou%.com/")
    if start ~= nil then
	    local pattern_name   = "\"title\"%s*:%s*\"(.-)\""
		local pattern_artist = "\"artist\"%s*:%s*\"(.-)\""

	    start, _, tmp = string.find(str, pattern_name)
	    --print(start, tmp)
	    if start == nil then return ""  else base_name = tmp end
	    base_name = string.gsub(base_name, "<.->", "")
	
	    start, _, tmp = string.find(str, pattern_artist)
	    --print(start, tmp)
	    if start == nil then return "" else artist = tmp end 
	    artist = string.gsub(artist, "<.->", "")
	    
	    start, _, tmp = string.find(linkurl, pattern_ext)
	    --print(start, tmp)
	    if start == nil then return "" else ext = tmp end 

	    return artist .. " - " .. base_name .. ext
    end

    start = string.find(referurl, "mp3%.sogou%.com/")
    if start ~= nil then

	    local pattern_name   = "<TD>歌名：<A[^>]+>(.-)</A>"
		local pattern_artist = "<TD>歌手：<A[^>]+>(.-)</A>"

	    start, _, tmp = string.find(str, pattern_name)
	    --print(start, tmp)
	    if start == nil then return ""  else base_name = tmp end
	    base_name = string.gsub(base_name, "<.->", "")
	
	    start, _, tmp = string.find(str, pattern_artist)
	    --print(start, tmp)
	    if start == nil then return "" else artist = tmp end 
	    artist = string.gsub(artist, "<.->", "")
	    
	    start, _, tmp = string.find(linkurl, pattern_ext)
	    --print(start, tmp)
	    if start == nil then return "" else ext = tmp end 

	    return artist .. " - " .. base_name .. ext
	end
	
	return "" 
end

function url_query(str)
    local start
    local pattern_url = "mp3%.sogou%.com/"

    start = string.find(str, pattern_url)
    if start ~= nil then
        return true
    end

	pattern_url = "ting%.mbox%.sogou%.com/"
    start = string.find(str, pattern_url)
    if start ~= nil then
        return true
    end

    return false
end

f = {}
f.process = url_process
f.accept = url_query
intelligent_name_table["mp3_sogou.lua"] = f

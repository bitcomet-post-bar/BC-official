local function f(url)
	local url_pattern1 = "%s*http://%a+%.newhua%.com/down/"
	local url_pattern2 = "%s*http://%a+%.onlinedown%.net/down/"
	local cookie = "Flag=UUIISPoweredByUUSoft" 

	if nil == string.find(url, url_pattern1) then 
		if nil == string.find(url, url_pattern2) then
			return nil, nil
		else
			return nil, cookie
		end
	else
		return nil, cookie
	end
end

referer_table["refer_newhua.lua"] = f

﻿function url_process(linkurl, fileurl, str)
    local pattern_name = "<[Tt][Ii][Tt][Ll][Ee]>(.-)%s*%- 华军软件园.*</[Tt][Ii][Tt][Ll][Ee]>"
    local pattern_ext  = ".*(%..*)$"
    local start, _, tmp

    local base_name, ext

    start, _, tmp = string.find(str, pattern_name)
    if start == nil then return ""  else base_name = tmp end

    start, _, tmp = string.find(linkurl, pattern_ext)
    if start == nil then return "" else ext = tmp end 

    return base_name .. ext
end

function url_query(str)
    local start
	local url_table = {}
	local i

	url_table[0] = "%.onlinedown.net/soft/"
	url_table[1] = "http://www.newhua.com/soft/"
	url_table[2] = "http://js.newhua.com/soft/"

	for i = 0,2 do
		start = string.find(str, url_table[i])
		if start ~= nil then return true end
	end

    return false
end


f = {}
f.process = url_process
f.accept = url_query
inteligent_name_table["soft_newhua.lua"] = f

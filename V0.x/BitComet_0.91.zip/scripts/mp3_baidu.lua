﻿function url_process(linkurl, fileurl, str)
    local pattern_name = "歌曲名：.->(.-)%s*...<"
    local pattern_url  = "歌曲名：.-href=\"(.-)\""
    local pattern_ext  = ".*(%..-)$"
    local start, _, tmp

    local base_name, ext, url

    start, _, tmp = string.find(str, pattern_name)
    print(start, tmp)
    if start == nil then return ""  else base_name = tmp end

    start, _, tmp = string.find(str, pattern_url)
    print(start, tmp)
    if start == nil then return "" else url = tmp end 

    start, _, tmp = string.find(url, pattern_ext)
    print(start, tmp)
    if start == nil then return "" else ext = tmp end 

    return base_name .. ext
end

function url_query(str)
    local start
    local pattern_url = "220%.181%.38%.82"

    start = string.find(str, pattern_url)
    if start == nil then
        return false
    end

    return true
end

f = {}
f.process = url_process
f.accept = url_query
inteligent_name_table["mp3_baidu.lua"] = f

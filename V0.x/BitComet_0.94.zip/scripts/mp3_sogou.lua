﻿function url_process(linkurl, fileurl, str)
    local pattern_name = "\"title\"%s*:%s*\"(.-)\""
	local pattern_ext = "\"postfix\"%s*:%s*\"(.-)\""
    local start, _, tmp

    local base_name, ext, url

    start, _, tmp = string.find(str, pattern_name)
    --print(start, tmp)
    if start == nil then return ""  else base_name = tmp end
    base_name = string.gsub(base_name, "<.->", "")

    start, _, tmp = string.find(str, pattern_ext)
    --print(start, tmp)
    if start == nil then return "" else ext = tmp end 
    ext = "." .. string.lower(ext)

    return base_name .. ext
end

function url_query(str)
    local start
    local pattern_url = "mp3%.sogou%.com/"

    start = string.find(str, pattern_url)
    if start == nil then
        return false
    end

    return true
end

f = {}
f.process = url_process
f.accept = url_query
inteligent_name_table["mp3_sogou.lua"] = f

﻿function url_process(linkurl, fileurl, str)
	if fileurl == "" or fileurl == nil then
		return ""
	end

    local pattern_name = "<[Tt][Ii][Tt][Ll][Ee]>%s*(.-)%s*软件下载%-太平洋下载中心</[Tt][Ii][Tt][Ll][Ee]>"
    local pattern_ext  = ".*(%..*)%s*$"
    local start, _, tmp

    local base_name, ext

    start, _, tmp = string.find(str, pattern_name)
    if start == nil then return ""  else base_name = tmp end

    start, _, tmp = string.find(fileurl, pattern_ext)
    if start == nil then return "" else ext = tmp end 

    return base_name .. ext
end

function url_query(str)
    local start
    local pattern_url = "http://dl%.pconline%.com%.cn/"

    start = string.find(str, pattern_url)
    if start == nil then return false end

    return true
end

f = {}
f.process = url_process
f.accept = url_query
inteligent_name_table["soft_pconline.lua"] = f

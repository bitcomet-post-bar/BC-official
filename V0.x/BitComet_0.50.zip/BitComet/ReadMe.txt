BitComet Readme
--------------------------------------------------
Bitcomet is a p2p file-sharing freeware fully compatible with BitTorrent, designed for the high-speed distribution of 100MB or GB sized files. BitComet is a easy-to-use multitorrent client for Win32 platforms, along with lots of improvements. Support download certain files within torrent, disk cache, fast resume, port mapping, speed limits, etc. Small, clean, and fast. No adware or spyware.

Feature
--------------------------------------------------
1.  Completely new core written in C++, stable and fast, very low CPU usage. 
2.  Multiple simultaneous downloads, ability to download specificated files in one torrent. 
3.  Intelligent resume and seeding, no long-time scanning at all.  
4.  Port mapping in ICS/ICF, UPnP hardware router, no need to do manually configuration.
5.  Ability to limit the upload speed as well as download speed. 
6.  Simple-look but handy interface, easy to learn how to use at all. 
7.  Disk cache mechanism, decrease the potential damage to the hard disk when high-speed downloading.
8.  Ability to add .bc! file extension to indicate unfinished files. 
9.  Using only one TCP listening port.
10. Support Muti-tracker torrent format, and utf-8 extension.
11. No need to install, but install/uninstall packages are provided.

License
--------------------------------------------------
Copyright (C) 2003-2004 ~RnySmile~ <bitcomet@yahoo.com>
Freeware for non-commercial use (at home). Please refer to license.txt for more details.

Contents
--------------------------------------------------
 1 Installation
 2 Upgrade
 3 Uninstall
 4 Newbie how-to
 5 Available short-cuts
 6 Further information

 1 Installation
-----------------
  Just run the installer will be OK
  version without installer available at http://www.bitcomet.com/achive/
  NOTE:
    MSXML3 is required, which is included with Windows XP or IE 6.0.
    You can download MSXML3 from Microsoft Download Center:
    http://www.microsoft.com/downloads/details.aspx?displaylang=en&FamilyID=c0f86022-2d4c-4162-8fb8-66bfc12f32b0

 2 Upgrade
------------
   Just install in the folder your old version was in.
   Your old settings will still be there as is your queue.

 3 Uninstall
--------------
  There is an uninstaller as well ...
  If you didn't use the installer: Just delete the folder, there are no .dll's or registry settings :)

 4 Newbie how-to
-------------------------------------------------
  Install BitComet. Start BitComet. Double click one of those bittorrent sites on the left (e.g. http://www.suprnova.org/), a webpage popups in your favourite internet explorer, click what you want (.torrent file), then the downloads dialog of BitComet popups, choose a directory to store it, click OK, download begins.

 5 Available short-cuts (in torrent list)
-------------------------------------------------
  DEL       : remove torrent
  Ctrl+DEL  : remove torrent including downloaded files
  Ctrl+UP   : move task up
  Ctrl+DOWN : move task down
  Ctrl+A    : seletcted all tasks
  Alt+ENTER : properities of task
  
 6 Further information
------------------------
  * Homepage                  @ http://www.bitcomet.com/
  * Forum                     @ http://www.p2pforums.com/viewforum.php?f=35
  
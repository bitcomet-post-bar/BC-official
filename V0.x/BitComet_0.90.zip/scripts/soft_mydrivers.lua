﻿function url_process(linkurl, fileurl, str)
    local pattern_name = "<[Dd][Ii][Vv] class=biaoti>%s*(.-)%s*</[Dd][Ii][Vv]>"
    local pattern_ext  = ".*(%..-)$"
    local start, _, tmp

    local base_name, ext

    start, _, tmp = string.find(str, pattern_name)
    --print(start, tmp)
    if start == nil then return ""  else base_name = tmp end

	base_name = string.gsub(base_name, "<WBR>", "")

    start, _, tmp = string.find(linkurl, pattern_ext)
    --print(start, tmp)
    if start == nil then return "" else ext = tmp end 

    return base_name .. ext
end

function url_query(str)
    local start
    local pattern_url = "http://drivers%d%.mydrivers.com/download/"

    start = string.find(str, pattern_url)
    if start == nil then return false end

    return true
end

f = {}
f.process = url_process
f.accept = url_query
inteligent_name_table["soft_mydrivers.lua"] = f

local function f(url)
	local url_pattern = "%s*http://count%.skycn%.com/softdownload%.php"
	local rand = math.random(1, 5000);
	if nil == string.find(url, url_pattern) then 
		return nil
	else
		return "http://www.skycn.com/soft/".. rand .. ".html"
	end
end

referer_table["refer_skycn.lua"] = f

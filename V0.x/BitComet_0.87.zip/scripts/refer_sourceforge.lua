local function f(url)
	local url_pattern = "%s*http://downloads.sourceforge.net/sourceforge/"
	if nil == string.find(url, url_pattern) then 
		return nil
	else
		return "http://sourceforge.net/project/downloading.php"
	end
end

referer_table["refer_sourceforge.lua"] = f

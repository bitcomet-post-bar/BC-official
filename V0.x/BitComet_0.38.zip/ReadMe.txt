BitComet 0.38
=================
A p2p progam following BitTorrent Protocol.

Key Feature
==============
1. complete new core writing in C++��Low CPU and memory usage.
2. Selected download in one torrent.
3. Only One listening port is need
4. Disk cache, decrease the potential damage to harddisk when high-speed downloading
5. Auto save Status of downloading task, no need to rescan files next time.
6. No need to scan files when seeding.
7��Muti-Language supported.

Other Feature
==============
1��Support Muti-tracker torrent format.
2. No need to install, except auto registe .torrent file extension. ( I will try to avoid it in next version)

Copyright
==============
Freeware. Totally free to use, But All rights reserved to the author, of course. 

Software Homepage:
===========================
http://www.bitcomet.org/

Contact Me in Forum:
====================
Chinese Forum: http://bbs.btchina.net/forumdisplay.php?s=&forumid=17
English Forum: http://www.filesoup.com/phpBB2/viewforum.php?f=9

Author
==============
~RnySmile~ <bitcomet@yahoo.com>

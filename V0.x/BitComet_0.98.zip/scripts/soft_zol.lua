﻿function url_process(linkurl, fileurl, str)
	if fileurl == "" or fileurl == nil then
		return ""
	end

    local pattern_name = "var soft_name%s*=%s*'(.-)'"
	local pattern_ext = ".*(%..*)%s*$"
    local start, _, tmp

    local base_name, ext

    start, _, tmp = string.find(str, pattern_name)
    if start == nil then return ""  else base_name = tmp end

    start, _, tmp = string.find(fileurl, pattern_ext)
    if start == nil then return "" else ext = tmp end 

    return base_name .. ext
end

function url_query(str)
    local start
	local url_table = {}
	local i

	url_table[0] = "http://download.www.xiyuit.com/link/"  
	url_table[1] = "http://www.5down.com/detail/"          
	url_table[2] = "http://download.www.ea3w.com/link/"    
	url_table[3] = "http://download.zol.com.cn/"           
	url_table[4] = "http://download.www.fengniao.com/link/"

	for i = 0,4 do
		start = string.find(str, url_table[i])
		if start ~= nil then return true end
	end

    return false
end

f = {}
f.process = url_process
f.accept = url_query
inteligent_name_table["soft_zol.lua"] = f

BitComet
==============
BitComet is a p2p freeware fully compatiable with BitTorrent, along with a lot of improvement. No adware or spyware.

Key Feature
==============
1. Completely new network core with state-of-art designing, very low CPU and RAM usage.
2. Simple-look but handy interface, no need to learn how to use at all. 
3. Disk cache mechanism, decrease the potential damage to the hard disk when high-speed downloading.
4. Ability to download selected files in one torrent.
5. Intelligent resume and seeding, do not require long-time scanning.
6. Only one listening port is needed, no matter how many simultaneous downloads.

Other Feature
==============
1. Support Muti-tracker torrent format.
2. Muti-Language supported.
3. No need to install, associate .torrent file only at run time.

Installation Notice:
==============
MSXML3 is required, which is included with IE 6.0.
You can also download MSXML3 From Microsoft Download Center:
http://www.microsoft.com/downloads/details.aspx?displaylang=en&FamilyID=c0f86022-2d4c-4162-8fb8-66bfc12f32b0

Copyright
==============
Freeware for non-commercial use (at home). Please refer to license.txt for more details.

Software Homepage:
==============
http://www.bitcomet.org/

Contact Me in Forum:
==============
Chinese Forum: http://bbs.btchina.net/forumdisplay.php?s=&forumid=17
English Forum: http://www.filesoup.com/phpBB2/viewforum.php?f=9

Author
==============
~RnySmile~ <bitcomet@yahoo.com>

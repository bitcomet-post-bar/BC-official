BitComet
==============
Bitcomet is a p2p file-sharing freeware fully BitTorrent compatible, designed for high-speed download 100MB or GB sized files, supports multiple simultaneous downloads, selected downloads, disk cache, fast resume, auto port mapping, speed limits, etc. No adware or spyware.

Feature
==============
1.  Completely new core written in C++, stable and fast, very low CPU and RAM usage. 
2.  Multiple simultaneous downloads, ability to selected download in one torrent. 
3.  Intelligent resume and seeding, no long-time scanning at all.  
4.  UPnP Auto Port Mapping, no need to manually config NAT in most case.  
5.  Ability to limit the upload speed as well as download speed.  
6.  Simple-look but handy interface, no need to learn how to use at all. 
7.  Disk cache mechanism, decrease the potential damage to the hard disk when high-speed downloading.  
8.  Ability to add .bc! file extension for unfinished files. 
9.  Only one listening port is needed, no matter how many simultaneous downloads.  
10.  Support Muti-tracker torrent format, and utf-8 extension 
11.  Auto Update Checker.  
12.  Muti-Language supported.  
13.  No need to install, but install/uninstall packages are provided. 

Installation Notice:
==============
MSXML3 is required, which is included with IE 6.0.
You can also download MSXML3 from Microsoft Download Center:
http://www.microsoft.com/downloads/details.aspx?displaylang=en&FamilyID=c0f86022-2d4c-4162-8fb8-66bfc12f32b0

Copyright
==============
Freeware for non-commercial use (at home). Please refer to license.txt for more details.

Software Homepage:
==============
http://www.bitcomet.com/

Author
==============
~RnySmile~ <bitcomet@yahoo.com>

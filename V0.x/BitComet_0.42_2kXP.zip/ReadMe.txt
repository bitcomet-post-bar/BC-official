BitComet
==============
BitComet is a p2p file-sharing freeware fully compatiable with BitTorrent, along with a lot of improvement. No adware nor spyware.

Key Feature
==============
1. Completely new network core with state-of-the-art designing, very low CPU and RAM usage.
2. Simple-look but handy interface, no need to learn how to use at all. 
3. Disk cache mechanism, decrease the potential damage to the hard disk when high-speed downloading.
4. Ability to download selected files in one torrent.
5. Intelligent resume and seeding, do not require long-time scanning.
6. UPnP Auto Port Mapping (new). 
7. Add .bc! file extension for unfinished files (new). 

Other Feature
==============
1. Support Muti-tracker torrent format.
2. Muti-Language supported.
3. No need to install, able to associate .torrent file only at run time.
4. Only one listening port is needed, no matter how many simultaneous downloads.

Installation Notice:
==============
MSXML3 is required, which is included with IE 6.0.
You can also download MSXML3 From Microsoft Download Center:
http://www.microsoft.com/downloads/details.aspx?displaylang=en&FamilyID=c0f86022-2d4c-4162-8fb8-66bfc12f32b0

How to Manually Upgrade and Keep Your Downloads(Thanks to Elliott Wilcoxon):
==============
1. Download the new version and unzip it to a temporary directory.
2. Go to the directory where BitComet is installed. (DONOT run Bitcomet here.)
3. Copy the contents of the BitComet zip file that you unzipped into the directory that BitComet was installed in.
   Remember Downloads.xml, BitComet.xml, the Downloads, Torrents, Status directories keep all your previews downloads.
5. Run BitComet.

Copyright
==============
Freeware for non-commercial use (at home). Please refer to license.txt for more details.

Software Homepage:
==============
http://www.bitcomet.com/

Author
==============
~RnySmile~ <bitcomet@yahoo.com>

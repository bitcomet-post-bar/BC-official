local function f(url)
	local url_pattern = "%s*http://count%.crsky%.com/view_down%.asp%?down_url"
	local rand = math.random(1, 5000);
	local cookie = nil
	if nil == string.find(url, url_pattern) then 
		return nil, cookie
	else
		return "http://crsky.com/soft/".. rand .. ".html", cookie
	end
end

referer_table["refer_crsky.lua"] = f

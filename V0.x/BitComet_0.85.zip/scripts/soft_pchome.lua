﻿function url_process(linkurl, fileurl, str)
    local pattern_name = "<[Hh]1><[Aa] title.->(.-)</[Aa]></[Hh]1>"
    local pattern_ext  = "url=.*(%..-)&svr"
    local start, _, tmp

    local base_name, ext

    start, _, tmp = string.find(str, pattern_name)
    --print(start, tmp)
    if start == nil then return ""  else base_name = tmp end

    start, _, tmp = string.find(linkurl, pattern_ext)
    --print(start, tmp)
    if start == nil then return "" else ext = tmp end 

    return base_name .. ext
end

function url_query(str)
    local start

    start = string.find(str, "http://download%.pchome%.net/")
    if start ~= nil then return true end

	return false
end

f = {}
f.process = url_process
f.accept = url_query
inteligent_name_table["soft_pchome.lua"] = f
